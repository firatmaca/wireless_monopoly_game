#ifndef SEC_H
#define SEC_H

#include <QDialog>
#include<QGraphicsView>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include<QGraphicsScene>
#include<cards.h>
#include <mainwindow.h>
namespace Ui {
class sec;
}

class sec : public QDialog
{
    Q_OBJECT

public:

    Cards array[41];

    explicit sec(QWidget *parent = 0);
    ~sec();
signals:

public slots:

    void on_pushButton_34_clicked();


private:
    Ui::sec *ui;

};

#endif // SEC_H
