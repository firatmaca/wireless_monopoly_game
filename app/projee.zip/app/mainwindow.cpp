#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "sec.h"
MainWindow::MainWindow(QWidget *parent) :

    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
}

MainWindow::~MainWindow()
{

    delete ui;
}

void MainWindow::set(int x){
    numberofplayer=x;
}
int MainWindow::get(){
    return numberofplayer;
}
void MainWindow::on_pushButton_clicked()
{
    MainWindow m;
    m.set(2);
sec se;
se.setModal(true);
se.exec();
}
void MainWindow::on_pushButton_2_clicked()
{
    MainWindow m;
      m.set(3);
sec se;
se.setModal(true);
se.exec();
}
void MainWindow::on_pushButton_3_clicked()
{
    MainWindow m;
      m.set(4);
sec se;
se.setModal(true);
se.exec();
}
void MainWindow::on_pushButton_4_clicked()
{MainWindow m;
    m.set(5);
sec se;
se.setModal(true);
se.exec();
}
void MainWindow::on_pushButton_5_clicked()
{
    MainWindow m;
      m.set(6);
sec se;
se.setModal(true);
se.exec();

}
void MainWindow::on_pushButton_6_clicked()
{MainWindow m;
    m.set(7);
sec se;
se.setModal(true);
se.exec();

}
void MainWindow::on_pushButton_7_clicked()
{
    MainWindow m;
      m.set(8);
sec se;
se.setModal(true);
se.exec();

}
