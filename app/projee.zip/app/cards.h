#ifndef CARDS_H
#define CARDS_H
#include "QString"
class Cards
{
public:
    int x,y;
        QString name;
        int cost;
    Cards();
    void setval(int ,int,QString,int );
};

#endif // CARDS_H
