#include "sec.h"
#include "ui_sec.h"
#include "QGraphicsView"
#include "QGraphicsRectItem"
#include"QGraphicsScene"
#include "cards.h"
#include "mainwindow.h"
sec::sec(QWidget *parent) :
    QDialog(parent),
     ui(new Ui::sec)

{
    array[0].setval(0,740,"GO",0);
    array[1].setval(0,670,"VISNELIK",140);
    array[2].setval(0,600,"ELEKTRIK ISLERI",150);
    array[3].setval(0,530,"VADISEHIR",140);
    array[4].setval(0,460,"SUMER",160);
    array[5].setval(0,390,"TREN GARI",200);
    array[6].setval(0,320,"PASA",180);
    array[7].setval(0,250,"CHEST",0);
    array[8].setval(0,180,"EMEK",180);
    array[9].setval(0,110,"GOZTEPE",200);
    array[10].setval(0,0,"INJAIL",0);
    array[11].setval(110,0,"ARIFIYE",220);
    array[12].setval(180,0,"CHANCE",0);
    array[13].setval(250,0,"DEDE",220);
    array[14].setval(320,0,"HUZUR",240);
    array[15].setval(390,0,"PORSUK GEZINTISI",200);
    array[16].setval(460,0,"CAVLUM",260);
    array[17].setval(530,0,"GOKMEYDAN",260);
    array[18].setval(600,0,"SU ISLERI",150);
    array[19].setval(670,0,"ISTIKLAL",280);
    array[20].setval(740,0,"FREEPARKING",0);
    array[21].setval(750,110,"ALANONU",300);
    array[22].setval(750,180,"CUMHURIYE",300);
    array[23].setval(750,250,"CHEST",0);
    array[24].setval(750,320,"KALKANLI",320);
    array[25].setval(750,390,"OTOGAR",200);
    array[26].setval(750,460,"CHANCE",0);
    array[27].setval(750,530,"75.YIL",350);
    array[28].setval(750,600,"LUXARYTAX",100);
    array[29].setval(750,670,"71EVLER",400);
    array[30].setval(740,740,"GOTOJAIL",0);
    array[31].setval(670,750,"TEPEBASI",60);
    array[32].setval(600,750,"CHEST",0);
    array[33].setval(530,750,"ODUNPAZARI",60);
    array[34].setval(460,750,"GELIRVERGISI",200);
    array[35].setval(390,750,"HIZLITREN",200);
    array[36].setval(320,750,"GUNDOGDU",100);
    array[37].setval(250,750,"CHANCE",0);
    array[38].setval(180,750,"ERENKOY",120);
    array[39].setval(110,750,"GULTEPE",120);

ui->setupUi(this);
}
sec::~sec()
{

    delete ui;
}

 int top=0,son=0;

void sec::on_pushButton_34_clicked()
{
    int a=(rand()%6+1);
    int b=(rand()%6+1);

    ui->label_4->setText(QString::number(a));
    ui->label_5->setText(QString::number(b));
    int c=a+b;
     top=top+c;
     son=top%40;
    ui->label_6->move(array[son].x,array[son].y);
    MainWindow m;

    ui->label_7->setText(QString::number(m.get()));
}

