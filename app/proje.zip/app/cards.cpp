#include "cards.h"
#include "QString"
Cards::Cards()
{
    x=0;
    y=0;
    name=" ";
    cost=0;
}
void Cards::setval(int n,int m,QString nameofhouse,int costofhouse)
{
    x=n;
    y=m;
    name=nameofhouse;
    cost=costofhouse;
}
